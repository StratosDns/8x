

public class Protocol {
    public static final String SIGNIN = "SIGNIN";
    public static final String SIGNOUT = "SIGNOUT";
    public static final String SEARCH = "SEARCH";
    public static final String OK = "OK";
    public static final String ERROR = "ERROR";
    public static final String RESULTS = "RESULTS";
}