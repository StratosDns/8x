public class Protocol {
    public static final int MAIL_SEND = 1;
    public static final int MAIL_REQUEST = 2;
    public static final int MAIL_FORWARD = 3;
    public static final int SIGNIN = 4;
    public static final String OK = "OK";
    public static final String ERROR = "ERROR";
}