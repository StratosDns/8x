import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

public class MessageHandler implements Runnable {
    private Socket clientSocket;
    private EmailServer server;
    private BufferedReader in;
    private PrintWriter out;
    private String username;

    public MessageHandler(EmailServer server, Socket socket) {
        this.server = server;
        this.clientSocket = socket;
        try {
            this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.out = new PrintWriter(socket.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                System.out.println("Server received: " + inputLine); // Debug
                String[] parts = inputLine.split(" ", 2);
                int command = Integer.parseInt(parts[0]);

                switch (command) {
                    case Protocol.SIGNIN -> handleSignin(parts[1]);
                    case Protocol.MAIL_SEND -> handleMailSend(parts[1]);
                    case Protocol.MAIL_REQUEST -> handleMailRequest();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleMailSend(String mailData) {
        try {
            // Extract username from recipient format (username@localhost:5000)
            String[] parts = mailData.split(" ", 2);
            String recipient = parts[0].split("@")[0]; // Get just the username
            String content = parts[1];
    
            System.out.println("Server: Sending mail from " + username + " to " + recipient);
            
            Email email = new Email(username, recipient, content);
            server.deliverMail(email);
            out.println(Protocol.OK);
        } catch (Exception e) {
            out.println(Protocol.ERROR);
            e.printStackTrace();
        }
    }

    private void handleMailRequest() {
        List<Email> emails = server.getMail(username);
        System.out.println("Server: Found " + emails.size() + " emails for " + username);
        
        if (emails.isEmpty()) {
            out.println("No messages in your mailbox.");
        } else {
            for (Email email : emails) {
                out.println("=== New Message ===");
                out.println("From: " + email.getFrom());
                out.println("Message: " + email.getContent());
                out.println("=================");
            }
        }
        out.println(Protocol.OK);
    }

    private void handleSignin(String username) {
        this.username = username;
        server.addClient(username, out);
        out.println(Protocol.OK);
        System.out.println("Server: User signed in: " + username); // Debug
    }
}