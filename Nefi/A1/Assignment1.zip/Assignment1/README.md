## Info
- `src`: the folder to maintain sources

 ## Steps to successfully run the server-client connection

 - Initially open a terminal inside the src directory and type 'java Server'.

 - After the Server has been started there is an open socket waiting for connection.

 - Open another terminal inside the src directory to run the Client side as 'java ClientGUI 127.0.0.1'.

 - Communication with external networks has not been implemented yet thereofore typing 127.0.0.1 / localhost / local ipv4 adrress is the same thing.

 - A new window will appear and the user has to enter a username, if the username is already in use there are unlimited tries until a successful one occurs.

 - The chat is ready to use and the user can sign out at any time by pressing the 'Sign out' designated button.

 

