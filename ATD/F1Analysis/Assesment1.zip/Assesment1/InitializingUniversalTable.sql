DROP TABLE IF EXISTS RESULTS_MODIFIED;
DROP TABLE IF EXISTS RACES_MODIFIED;
DROP TABLE IF EXISTS CIRCUITS_MODIFIED;
DROP TABLE IF EXISTS ENGINE_FAILURES CASCADE;
DROP TABLE IF EXISTS RESULTS CASCADE;
DROP TABLE IF EXISTS RACES CASCADE;
DROP TABLE IF EXISTS CIRCUITS CASCADE;

CREATE TABLE CIRCUITS (
    circuitId INT NOT NULL,
    circuitRef TEXT NOT NULL,
    circuit_name TEXT NOT NULL,
    circuit_location TEXT NOT NULL,
    circuit_country TEXT NOT NULL,
    lat REAL,
    lng REAL,
    alt REAL,
    RaceURL TEXT,
    PRIMARY KEY (circuitId));

COPY CIRCUITS FROM 'C:\uni\8x\ATD\archive\circuits.csv' DELIMITER ',' CSV HEADER;

CREATE TABLE RACES (
    raceId INT NOT NULL,
    year TEXT,
    round INT,
    circuitId INT NOT NULL,
    race_name TEXT NOT NULL,
    race_date TEXT,
    race_time TEXT,
    rurl TEXT,
    fp1_date TEXT,
    fp1_time TEXT,
    fp2_date TEXT,
    fp2_time TEXT,
    fp3_date TEXT,
    fp3_time TEXT,
    quali_date TEXT,
    quali_time TEXT,
    sprint_date TEXT,
    sprint_time TEXT,  
    FOREIGN KEY (circuitId) REFERENCES CIRCUITS(circuitId),
    PRIMARY KEY (raceId));

COPY RACES FROM 'C:\uni\8x\ATD\archive\races.csv' DELIMITER ',' CSV HEADER;


CREATE TABLE RESULTS (
    resultId INT NOT NULL,
    raceId INT NOT NULL,
    driverId INT,
    constructorId INT,
    numbered TEXT,
    grid INT,
    position TEXT,
    positionText TEXT,
    positionOrder TEXT,
    points REAL,
    laps INT,
    timed TEXT,
    milliseconds TEXT,
    fastestLap TEXT,
    ranked TEXT,
    fastestLapTime TEXT,
    fastestLapSpeed TEXT,
    statusId INT,
    FOREIGN KEY (raceId) REFERENCES RACES(raceId),
    PRIMARY KEY (raceId, resultId));

COPY RESULTS FROM 'C:\uni\8x\ATD\archive\results.csv' DELIMITER ',' CSV HEADER;

CREATE TABLE RESULTS_MODIFIED AS 
SELECT raceId, resultId, statusId FROM RESULTS;

CREATE TABLE RACES_MODIFIED AS 
SELECT raceId, circuitId FROM RACES;

CREATE TABLE CIRCUITS_MODIFIED AS 
SELECT circuitId, alt FROM CIRCUITS;

COPY CIRCUITS_MODIFIED TO 'C:\uni\8x\ATD\archive\circuits_modified.csv' DELIMITER ',' CSV HEADER;

COPY RACES_MODIFIED TO 'C:\uni\8x\ATD\archive\races_modified.csv' DELIMITER ',' CSV HEADER;

COPY RESULTS_MODIFIED TO 'C:\uni\8x\ATD\archive\results_modified.csv' DELIMITER ',' CSV HEADER;


COPY (
    select * FROM RACES_MODIFIED natural join RESULTS_MODIFIED natural join CIRCUITS_MODIFIED
) TO 'C:\uni\8x\ATD\archive\UNIVERSAL.csv' DELIMITER ',' CSV HEADER;


/*
Personal  Addition - Ignore this
CREATE TABLE ENGINE_FAILURES AS
SELECT r.circuitId, COUNT(*) AS failure_count, c.alt
FROM RESULTS res
JOIN RACES r ON res.raceId = r.raceId
JOIN CIRCUITS c ON r.circuitId = c.circuitId
WHERE res.statusId = 5
GROUP BY r.circuitid, c.alt
ORDER BY failure_count DESC;

SELECT * FROM ENGINE_FAILURES;

COPY ENGINE_FAILURES TO 'C:\uni\8x\ATD\archive\engine_failures.csv' DELIMITER ',' CSV HEADER;
*/
